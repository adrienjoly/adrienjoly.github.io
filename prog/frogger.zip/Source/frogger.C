//*******************************************************
//*                 FROGGER92+ by R�Ly!                 *
//*              last update :  29/09/2001              *
//*-----------------------------------------------------*
//*        [ www.roly.fr.st ] -=- [ roly@fr.st ]        *
//*                                                     *
//* Thanx to TIGCC team and Lee Chapel for inspiring me *
//*              with his PC game 'Leaper'              *
//*                                                     *
//*   This program is freely distributed with source    *
//*  code so you can modify it after asking me. It's my *
//*   first TIGCC program so don't hesitate to send me  *
//*               comments to roly@fr.st                *
//*                                                     *
//*   Frogger doesn't support Ti89 calculator because:  *
//*     - I'm beginner in TIGCC programming             *
//*     - There are enough ti89 games yet               *
//*     - It's easier to adapt a 89 program for the 92+ *
//*                                                     *
//*  Feel free to adapt Frogger for 89, send it to me.  *
//*                                                     *
//*      Visit www.roly.fr.st for last version.         *
//*                                                     *
//*                     HAVE FUN !!!                    *
//*******************************************************

#define OPTIMIZE_ROM_CALLS
#define SAVE_SCREEN
#include <tigcclib.h>

short _ti92plus;

//*************************
//DEFINITION DES SPRITES
//*************************

//cible: 15x15
static unsigned short cible[] ={ 0x3E0, 0xC18, 0x1004, 0x21C2, 0x2222, 0x4411, 0x4889, 0x4949, 0x4889, 0x4411, 0x2222, 0x21C2, 0x1004, 0xC18, 0x3E0};

//troncs: 16x14  petit: 1234   grand: 1235234
static unsigned short tronc1[] ={ 0x0, 0x0, 0x3FF0, 0x400F, 0x4FF0, 0x800F, 0x87F0, 0x800F, 0x87F0, 0x400F, 0x4FF0, 0x3FFF, 0xF, 0x0};
static unsigned short tronc2[] ={ 0x0, 0x0, 0x0, 0xF00F, 0xFF0, 0xE787, 0x1878, 0xF707, 0x1FF, 0xFE00, 0x1FF, 0xFE30, 0xE1CF, 0x1FF0};
static unsigned short tronc3[] ={ 0x0, 0x3, 0x7FD, 0xF81C, 0xFC3, 0xFC38, 0x73E3, 0x8E1C, 0xE1E7, 0x1FF8, 0xFC07, 0x3F8, 0xFC00, 0x0};
static unsigned short tronc4[] ={ 0x0, 0xFF00, 0x87FC, 0x7062, 0xFFDA, 0xE0D, 0xE1E1, 0x3FFD, 0xC001, 0x3FFA, 0xFC02, 0x3FC, 0x0, 0x0};
static unsigned short tronc5[] ={ 0x0, 0xFF00, 0x87FC, 0x7063, 0xFFD8, 0xE0F, 0xE1E1, 0x3FFC, 0xC007, 0x3FF8, 0xFC07, 0x3FC, 0x3, 0x0};

//tortues: 15x14
static unsigned short tortue1[] ={ 0x0, 0x803, 0x1C73, 0x79E, 0x264, 0x3696, 0x5D6A, 0x5D6A, 0x3696, 0x264, 0x79E, 0x1C73, 0x803, 0x0};
static unsigned short tortue2[] ={ 0x0, 0x0, 0x70, 0x39C, 0x264, 0x696, 0x56A, 0x56A, 0x696, 0x264, 0x39C, 0x70, 0x0, 0x0};
static unsigned short tortue3[] ={ 0x0, 0x0, 0x0, 0x0, 0x60, 0x90, 0x168, 0x168, 0x90, 0x60, 0x0, 0x0, 0x0, 0x0};
static unsigned short tortue4[] ={ 0x0, 0x0, 0x90, 0x204, 0x0, 0x422, 0x88, 0x2, 0x490, 0x0, 0x104, 0x20, 0x0, 0x0};

static unsigned long camion[] ={ 0x00000000, 0x00000000, 0x3C3FFFFE, 0xE2778BA1, 0xDE77B92F, 0x1DEB792F, 0xDE6B7AA3, 0xDE637AAF, 0x1DDD7BAF, 0xDE5DBBAF, 0xE25D8BA1, 0x3C3FFFFE, 0x00000000, 0x00000000};
static unsigned long espace[] ={ 0x00000000, 0x00F00F00, 0x030FF0C0, 0x1FFFFFE0, 0x77FFFFF0, 0xEFAAAAF0, 0xEF555570, 0xEFAAAAF0, 0xEF555570, 0x77FFFFF0, 0x1FFFFFE0, 0x030FF0C0, 0x00F00F00, 0x00000000};
static unsigned long f1[] ={ 0x00000000, 0x3E0F8000, 0x3E0F8000, 0x08023000, 0xFFFFB800, 0x7FFFF800, 0xE0003800, 0xE0003800, 0x7FFFF800, 0xFFFFB800, 0x08023000, 0x3E0F8000, 0x3E0F8000, 0x00000000};
static unsigned long voiture[] ={ 0x00000000, 0x7E000000, 0x66000000, 0x181500E0, 0x3F2AE040, 0x7FEABFE0, 0xFFEABFF0, 0xFFEABFF0, 0x7FEABFE0, 0x3F2AE040, 0x181500E0, 0x66000000, 0x7E000000, 0x00000000};
static unsigned short grenouille[] ={ 0xC0, 0x1E0, 0x2AD5, 0x3BF7, 0x1332, 0x1B36, 0xF3C, 0x618, 0x618, 0x618, 0xF3C, 0x2DED, 0x3807, 0x1002};


//*************************
//PROCEDURE PRINCIPALE
//*************************

void _main(void)
{

   void *virtual = malloc (3840);   //LCD_SIZE: 3840
   void *virtual2 = malloc(3840);
   
	 int quit;
   int vies;

   int i;
   int keyp;
   int keyp2;
   
   int edge;
   int score;
   static int best_score[3] = {3, 2, 1};
   static char best_player[3][12] = {"Frogger","by R�Ly!","roly@fr.st"};
   
  int etage;
  int x;
  int y;
  
  int cible_hit;
  int cibles;
  int cible_ok[6];
  
  int tronc_pos[28]={ 0,  0, 16, 32, 48, 64, 80, 96,144,160,176,192,  0, 16, 32, 48, 80, 96,112,128,160,176,192,208,  0, 16, 32, 48};
  //////////////////////  1   2   3   4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25  26  27
  int tortue_pos[23]={0,  0, 16, 32, 48, 80, 96,112,128,160,176,192,208,  0, 16, 48, 64, 96,112,144,160,192,208};
   
  int camion_pos=200;
  int f1_pos=0;
  int espace_pos=200;
  int voiture_pos=0;
  
  INT_HANDLER save_int_1;


//*************************
//PROCEDURE "DRAWROAD"
//*************************

   void drawroad(void){
      memset (virtual, 0, 3600);    //seule la barre est conserv�e
      PortSet (virtual, 239, 127);

      DrawLine (0, 29+etage, LCD_WIDTH, 29+etage, A_SHADE_NS);
      DrawLine (0, 44+etage, LCD_WIDTH, 44+etage, A_NORMAL);
      for(i=0; i<LCD_WIDTH; i=i+20){
         if (etage<61) DrawLine (i, 59+etage, i+12 , 59+etage, A_NORMAL);
        if (etage<46) DrawLine (i, 74+etage, i+12 , 74+etage, A_NORMAL);
        if (etage<31) DrawLine (i, 89+etage, i+12 , 89+etage, A_NORMAL);
      }
      if (etage<16) DrawLine (0, 104+etage, LCD_WIDTH, 104+etage, A_NORMAL);

      memcpy (LCD_MEM,virtual,3840);   //restauration de l'�cran
      PortSet (LCD_MEM, 239, 127);

      printf_xy(LCD_WIDTH-25,LCD_HEIGHT-6,"%d", score);}


//*************************
//PROCEDURE "CARRE"
//*************************
   void carre(int largeur, int hauteur){
      int x1, y1;
      int p,i;
      x1=(LCD_WIDTH)/2;
      y1=(LCD_HEIGHT)/2;
      for(p=0;p<=50;p++){
         for(i=y1-(p*hauteur/100);i<=y1+(p*hauteur/100);i++){
            DrawLine (x1-(p*largeur/100), i, x1+(p*largeur/100), i, A_REVERSE);
         }
         DrawLine (x1-p*largeur/100,y1-p*hauteur/100,x1+p*largeur/100,y1-p*hauteur/100,A_NORMAL);
         DrawLine (x1+p*largeur/100,y1-p*hauteur/100,x1+p*largeur/100,y1+p*hauteur/100,A_NORMAL);
         DrawLine (x1+p*largeur/100,y1+p*hauteur/100,x1-p*largeur/100,y1+p*hauteur/100,A_NORMAL);
         DrawLine (x1-p*largeur/100,y1+p*hauteur/100,x1-p*largeur/100,y1-p*hauteur/100,A_NORMAL);
   }}    


//*************************
//PROCEDURES "CARRE" + "KEYON" + "KEYOFF" + "WAITFORKEY"
//*************************

   void keyon(void){
      SetIntVec(AUTO_INT_1,DUMMY_HANDLER);}

   void keyoff(void){
      SetIntVec(AUTO_INT_1,save_int_1);}

   short waitforkey(void){
   	short k;
   	GKeyFlush();
   	while(!(k=ngetchx()));
   	GKeyFlush();
   	return k;}


//*************************
//PROCEDURE "ECRASE"
//*************************

   void ecrase(void){

      int position, p;
      short key, captured, ii;

      void CaptureHandler (EVENT *ev){if (ev->Type==CM_STRING) captured=*(ev->extra.pasteText);}

      keyoff();
   vies--;
   
   if (vies<1){
      position=0;
      if (score>best_score[0]) position=1;
      else if (score>best_score[1]) position=2;
      else if (score>best_score[2]) position=3;
         carre(190,100);
         FontSetSys(F_8x10);
         printf_xy(40,20,"Tableau des records");
         FontSetSys(F_6x8);
         for(i=0;i<3;i++){
            if (position==i+1){
               for(p=2;p>i;p--){
                  strcpy (best_player[p], best_player[p-1]); 
                  best_score[p]=best_score[p-1];}
               best_score[i]=score;
            }else printf_xy(50,50+i*12,best_player[i]);
            printf_xy(180,50+i*12,"%d", best_score[i]);
         }
            
         if (position>0){
            i=position-1;
            DrawLine(50,47+i*12,170,47+i*12,A_NORMAL);
            DrawLine(170,47+i*12,170,60+i*12,A_NORMAL);
            DrawLine(170,60+i*12,50,60+i*12,A_NORMAL);
            DrawLine(50,60+i*12,50,47+i*12,A_NORMAL);
            GKeyFlush();

            best_player[i][0] = 0;
            ii=0;
            do
           {
             printf_xy(51,50+12*i,"%s_  ", best_player[i]);
             key = ngetchx();
             if (key == KEY_CHAR && ii < 13)
            {
              EVENT ev;
             ev.Type = CM_KEYPRESS;
              ev.extra.Key.Code = key;
              EV_captureEvents (CaptureHandler);
             EV_defaultHandler (&ev);
              EV_captureEvents (NULL);
             best_player[i][ii++] = captured;
            }
             if (key >= ' ' && key <= '~' && ii < 13) best_player[i][ii++] = key;
             if (key == KEY_BACKSPACE && ii) ii--;
                best_player[i][ii] = 0;
          } while (key != KEY_ENTER);
        }

         FontSetSys(F_4x6);
         printf_xy(45,105,"ENTREE pour rejouer, ECHAP pour quitter");
         quit=1;
         if (waitforkey()==KEY_ENTER) quit=2;

     }else{  //Il reste encore quelques vies
         carre(190,100);
         FontSetSys(F_8x10);
         if ((x<0) || (x>=LCD_WIDTH-14)) printf_xy(85,50,"DISPARU !");
          else if (y<5) printf_xy(80,50,"ECRASE !!!");
          else if (y<11) printf_xy(85,50,"PLOUF !!!");
          else printf_xy(85,50,"RATE !!!");
         printf_xy(55,80,"IL RESTE %d VIES", vies);
         FontSetSys(F_4x6);
   			 printf_xy(45,105,"ENTREE pour continuer, ECHAP pour quitter");
   			 if (waitforkey()==KEY_ESC) {quit=1; return;}
         x=113;
      	 y=0;
      	 edge=0;
      	 etage=0;
         drawroad();
     }
     keyon();
  }
  

//initialisation de frogger

   save_int_1=GetIntVec(AUTO_INT_1);
   rand();

//*************************
//records:
//*************************

   carre(190,100);
   FontSetSys(F_8x10);
   printf_xy(40,20,"Frogger92+ by R�Ly!");
   FontSetSys(F_4x6);
   printf_xy(42,32,"-- [ www.roly.fr.st ] -=-  [ roly@fr.st ] --");
   printf_xy(40,40,"thanx to TIGCC team and Lee 'Leaper' Chapel");
   
   
   FontSetSys(F_6x8);
   for(i=0;i<3;i++){
      printf_xy(50,58+i*12,"%s", best_player[i]);
      printf_xy(160,58+i*12,"%d", best_score[i]);}
   FontSetSys(F_4x6);
   printf_xy(45,105,"ENTREE pour continuer, ECHAP pour quitter");
   if (waitforkey()==KEY_ESC) goto fin;


//*************************
//NOUVELLE PARTIE
//*************************
again:
   
   camion_pos=random(201);
   f1_pos=random(201);
   espace_pos=random(201);
   voiture_pos=random(201);
   
   cible_ok[1]=0;
   cible_ok[2]=0;
   cible_ok[3]=0;
   cible_ok[4]=0;
   cible_ok[5]=0;
   cible_ok[6]=0;
   cibles=6;

   quit=0;
   x=113;
   y=0;
   vies=3;
   score=0;
   keyp=0;
   keyp2=0;
   edge=0;
   etage=0;

   keyon();
   
   memset (LCD_MEM, 0, 3840); //LCD_SIZE: 3840

   DrawLine (0, LCD_HEIGHT-8 , LCD_WIDTH, LCD_HEIGHT-8, A_NORMAL);
   FontSetSys(F_4x6);
   printf_xy(0,LCD_HEIGHT-6,"Frogger by R�Ly!");
   printf_xy(LCD_WIDTH-50,LCD_HEIGHT-6,"Score: 0");

   memcpy (virtual,LCD_MEM,3840);   //enregistrement de la barre

   drawroad();
      
  memset (virtual2, 0, 3840); //LCD_SIZE: 3840
  PortSet (virtual2, 239, 127);

  PortSet (LCD_MEM, 239, 127);   //acc�s direct au LCD

  do
  {
    memcpy (virtual2, virtual, 3600);     //AFFICHAGE DU FOND
    
    // DEPLACEMENT DES OBSTACLES ************************************

      for(i=24; i<28; i++){
         tronc_pos[i]+=2;
         if (tronc_pos[i]>=LCD_WIDTH) tronc_pos[i]=0;
      }
      
      for(i=1; i<23; i++){
         tortue_pos[i]-=2;
         if (tortue_pos[i]<=0) tortue_pos[i]=LCD_WIDTH;
      }

      for(i=1; i<12; i++){
         tronc_pos[i]++;
         if (tronc_pos[i]>=LCD_WIDTH) tronc_pos[i]=0;
      }

      for(i=12; i<24; i++){
         tronc_pos[i]+=2;
         if (tronc_pos[i]>=LCD_WIDTH) tronc_pos[i]=0;
      }
      
    camion_pos=camion_pos-1;
    f1_pos=f1_pos+3;
    espace_pos=espace_pos-1;
    voiture_pos=voiture_pos+2;

    if (camion_pos<=0) camion_pos=LCD_WIDTH;
    if (f1_pos>=LCD_WIDTH) f1_pos=0;
    if (espace_pos<=0) espace_pos=LCD_WIDTH;
    if (voiture_pos>=LCD_WIDTH) voiture_pos=0;

// AFFICHAGE DES SPRITES *****************************************

      if (etage>=60){
         for(i=1;i<7;i++){
            if (cible_ok[i]==0) Sprite16(i*LCD_WIDTH/7-7, etage-60, 14, cible, virtual2, SPRT_XOR);
         }
      }

      if (etage>=45){
        Sprite16 (tronc_pos[24], etage-45, 14, tronc1, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[25], etage-45, 14, tronc2, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[26], etage-45, 14, tronc3, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[27], etage-45, 14, tronc4, virtual2, SPRT_XOR);
      }

     if (etage>=30) for(i=13;i<23;i++) Sprite16(tortue_pos[i], etage-30, 14, tortue1, virtual2, SPRT_XOR);

      if (etage>=15){
        Sprite16 (tronc_pos[1], etage-15, 14, tronc1, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[2], etage-15, 14, tronc2, virtual2, SPRT_XOR);
      Sprite16 (tronc_pos[3], etage-15, 14, tronc3, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[4], etage-15, 14, tronc5, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[5], etage-15, 14, tronc2, virtual2, SPRT_XOR);
      Sprite16 (tronc_pos[6], etage-15, 14, tronc3, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[7], etage-15, 14, tronc4, virtual2, SPRT_XOR);

        Sprite16 (tronc_pos[8], etage-15, 14, tronc1, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[9], etage-15, 14, tronc2, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[10], etage-15, 14, tronc3, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[11], etage-15, 14, tronc4, virtual2, SPRT_XOR);
      }

      for(i=0;i<3;i++){
        Sprite16 (tronc_pos[12+i*4], etage, 14, tronc1, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[13+i*4], etage, 14, tronc2, virtual2, SPRT_XOR);
      Sprite16 (tronc_pos[14+i*4], etage, 14, tronc3, virtual2, SPRT_XOR);
        Sprite16 (tronc_pos[15+i*4], etage, 14, tronc4, virtual2, SPRT_XOR);
      }

     for(i=1;i<13;i++){
         if (i>4 && i<9 && tortue_pos[5]<=160){             //TORTUES PLONGENT
            if (tortue_pos[5]<=32)
              Sprite16 (tortue_pos[i], 15+etage, 14, tortue2, virtual2, SPRT_XOR);
            else if (tortue_pos[5]<=64)
              Sprite16 (tortue_pos[i], 15+etage, 14, tortue3, virtual2, SPRT_XOR);
            else if (tortue_pos[5]<=96)
              Sprite16 (tortue_pos[i], 15+etage, 14, tortue4, virtual2, SPRT_XOR);
            else if (tortue_pos[5]<=128)
              Sprite16 (tortue_pos[i], 15+etage, 14, tortue3, virtual2, SPRT_XOR);
            else
              Sprite16 (tortue_pos[i], 15+etage, 14, tortue2, virtual2, SPRT_XOR);
         }     
        else Sprite16 (tortue_pos[i], 15+etage, 14, tortue1, virtual2, SPRT_XOR);
     }

    if (etage<60) Sprite32 (camion_pos, 45+etage, 14, camion, virtual2, SPRT_XOR);
    if (etage<45) Sprite32 (f1_pos, 60+etage, 14, f1, virtual2, SPRT_XOR);
    if (etage<30) Sprite32 (espace_pos, 75+etage, 14, espace, virtual2, SPRT_XOR);
    if (etage<15) Sprite32 (voiture_pos, 90+etage, 14, voiture, virtual2, SPRT_XOR);

    Sprite16 (x, 105-y*15+etage, 14, grenouille, virtual2, SPRT_OR);
    
      memcpy (LCD_MEM,virtual2,3600); //partie visible derri�re la barre
      
      
      // GESTION DES COLLISIONS *******************************************
      
            if (y==11){             //ARRIVEE EN HAUT DE L'ECRAN
         cible_hit=0;
         for(i=1;i<7;i++) if(abs(x-i*LCD_WIDTH/7+7)<8 && cible_ok[i]==0) cible_hit=i;
         if (cible_hit){
            cible_ok[cible_hit]=1;
            cibles--;
            if (cibles==0){
               cibles=6;
               cible_ok[1]=0;
               cible_ok[2]=0;
               cible_ok[3]=0;
               cible_ok[4]=0;
               cible_ok[5]=0;
               cible_ok[6]=0;
               score+=500;
               keyoff();

      				 carre(190,100);
      				 FontSetSys(F_8x10);
				       printf_xy(LCD_WIDTH/2-60,LCD_HEIGHT/2-5,"FELICITATIONS !");

               FontSetSys(F_4x6);
               printf_xy(45,105,"ENTREE pour continuer, ECHAP pour quitter");
               if (waitforkey()==KEY_ESC) quit=1;
               keyon();
            } else score+=100;
            
            edge=0;
            etage=0;
            keyp=0;
            x=113;
         		y=0;
            drawroad();
            printf_xy(LCD_WIDTH-25,LCD_HEIGHT-6,"%d", score);
         }else ecrase();
      }
      
      else if (y==10){        //PETIT & DERNIER TRONC 
         if (x>tronc_pos[27]+9 && x<tronc_pos[27]+185) ecrase();
         else if(x<tronc_pos[24]-7 && x>tronc_pos[24]-184) ecrase();
         else x+=2;
      }

      else if (y==9){         //TORTUES 2 LE RETOUR
         if (x>tortue_pos[14]+9 && x<tortue_pos[14]+23) ecrase();
         else if (x>tortue_pos[16]+9 && x<tortue_pos[16]+23) ecrase();
         else if (x>tortue_pos[18]+9 && x<tortue_pos[18]+23) ecrase();
         else if (x>tortue_pos[20]+9 && x<tortue_pos[20]+23) ecrase();
         else if (x>tortue_pos[22]+9 && x<tortue_pos[22]+23) ecrase();
         else x-=2;
      }     
      
      else if (y==8){         //GRAND TRONC  
         if (x>tronc_pos[7]+9 && x<tronc_pos[7]+37) ecrase();
         else if(x>tronc_pos[11]+9 && x<tronc_pos[11]+37) ecrase();
         else x++;
      }

      else if (y==7){         //TRONC  
         if (x>tronc_pos[15]+9 && x<tronc_pos[15]+23) ecrase();
         else if(x>tronc_pos[19]+9 && x<tronc_pos[19]+23) ecrase();
         else if(x>tronc_pos[24]+9 && x<tronc_pos[24]+23) ecrase();
         else x+=2;
      }
      
      else if (y==6){         //TORTUES
         if (x>tortue_pos[4]+9 && x<tortue_pos[4]+23) ecrase();
         else if (x>tortue_pos[8]+9 && x<tortue_pos[8]+23) ecrase();
         else if (x>tortue_pos[12]+9 && x<tortue_pos[12]+23) ecrase();
         else x-=2;
      }     
      
     													//VOITURES   
     else if (y==4 && x>camion_pos-14 && x<camion_pos+32) ecrase();
    else if (y==3 && x>f1_pos-14 && x<f1_pos+21) ecrase();
    else if (y==2 && x>espace_pos-14 && x<espace_pos+28) ecrase();
    else if (y==1 && x>voiture_pos-14 && x<voiture_pos+28) ecrase();
    
    if(x<0 || x>LCD_WIDTH-15) ecrase();
    
    if (quit) break;


   // GESTION DU CLAVIER *********************************************
	 // Les codes clavier de la ti89 ont �t� pris en compte
	 
    if(_rowread(0x3FE)&0x10 || _rowread(0x7E)&0x2) x--;              //left
      else if(_rowread(0x3FE)&0x40 || _rowread(0x7E)&0x8) x++; 			//or right

    if(_rowread(0x3FE)&0x20 || _rowread(0x7E)&0x1){                  //up
        if(!keyp2){ y++; etage+=6; drawroad(); }
        keyp++;
      }
      else if(_rowread(0x3FE)&0x80 || _rowread(0x7E)&0x4){      		//or down
        if(!keyp2 && y){ y--; etage-=6; drawroad(); }
        keyp++;
    }
    
      if (keyp && edge<y){
         score+=10;
         edge=y;
         printf_xy(LCD_WIDTH-25,LCD_HEIGHT-6,"%d", score);
      }
  
    keyp2=keyp;
    keyp=0;    

    if(_rowread(0x2FF)&0x40 || _rowread(0x3F)&0x1){      //esc
         keyoff();
      	 carre(190,100);
      	 FontSetSys(F_8x10);
      	 printf_xy(LCD_WIDTH/2-32,LCD_HEIGHT/2-5,"PAUSE...");
         FontSetSys(F_4x6);
         printf_xy(45,105,"ENTREE pour continuer, ECHAP pour quitter");
         if (waitforkey()==KEY_ESC) quit=1;
         keyon();
    }

  }while(!quit);

   keyoff();
   PortRestore();

   if (quit==2) goto again;

	fin:

   free(virtual);
   free(virtual2);
}
